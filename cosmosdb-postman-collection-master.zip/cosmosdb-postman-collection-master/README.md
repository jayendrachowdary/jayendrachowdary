# cosmosdb-postman-collection
Postman v2 collection demonstrating REST access for CosmosDB

Every script in the collection uses a pre-request script to create the AUTH headers and format the request based on simply the URL, the functions in all of the requests are actually identical, so you can copy any request, change the uri and save again and it 

## Installation
From postman simply import the collection and the environment, add your access key and document db host in the collection and you're all set, you can use the scripts to create the initial database, then the collection and documents etc.
